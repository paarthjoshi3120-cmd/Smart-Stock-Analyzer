# Smart Stock Analyzer (Flask)

Team Code Geeks: Hariom Raturi, Paarth Joshi, Suryadev Singh. Project OSDBMS-V-2026-T139.

## Run
```bash
pip install -r requirements.txt
python app.py          # then open http://127.0.0.1:5000
```
The database (`stocks.db`) is created automatically on first run with 10 synthetic stocks
and a year of synthetic price history. Delete `stocks.db` to reset everything.

## Where the DBMS and OS ideas are
| Concept | Where |
|---|---|
| Normalised schema, PK/FK/CHECK/UNIQUE | `schema.sql` |
| Index on `transactions(user_id)` | `schema.sql` |
| Atomic ACID trade (BEGIN IMMEDIATE ... COMMIT / ROLLBACK) | `trade()` in `app.py` |
| Mutual exclusion, relative updates, fixed lock order | `trade()` |
| Worker threads per request | `app.run(threaded=True)` |
| Background price-update thread that sleeps between cycles | `price_updater()` |
| Risk score (Eq. 4) and 4-band decision engine | `risk_score()`, `decision()` |
| Average cost, profit/loss, break-even (Eqs. 1-3) | `trade()`, `portfolio()` |
| Audit trail of decisions | `logs` table |

## Notes
- Prices are synthetic. Educational use only, not financial advice.
- Buying is blocked in the restricted band (score > 0.85); selling stays allowed so users can exit.
- Set `SECRET_KEY` in the environment before any real deployment, and add CSRF protection (e.g. Flask-WTF).
