PRAGMA foreign_keys = ON;

CREATE TABLE users (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    cash          REAL    NOT NULL DEFAULT 100000 CHECK (cash >= 0),
    created_at    TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stocks (
    stock_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol        TEXT    NOT NULL UNIQUE,
    company       TEXT    NOT NULL,
    price         REAL    NOT NULL CHECK (price > 0),
    available_qty INTEGER NOT NULL CHECK (available_qty >= 0)
);

CREATE TABLE price_history (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    stock_id INTEGER NOT NULL REFERENCES stocks(stock_id),
    price    REAL    NOT NULL CHECK (price > 0),
    ts       TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_price_stock ON price_history(stock_id, id);

CREATE TABLE portfolio (
    user_id   INTEGER NOT NULL REFERENCES users(user_id),
    stock_id  INTEGER NOT NULL REFERENCES stocks(stock_id),
    quantity  INTEGER NOT NULL CHECK (quantity >= 0),
    avg_price REAL    NOT NULL,
    fees_paid REAL    NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, stock_id)
);

CREATE TABLE transactions (
    txn_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL REFERENCES users(user_id),
    stock_id INTEGER NOT NULL REFERENCES stocks(stock_id),
    type     TEXT    NOT NULL CHECK (type IN ('BUY','SELL')),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    price    REAL    NOT NULL CHECK (price > 0),
    fee      REAL    NOT NULL DEFAULT 0,
    ts       TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_txn_user ON transactions(user_id);   -- speeds up portfolio/history queries

CREATE TABLE logs (
    log_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(user_id),
    event      TEXT NOT NULL,
    risk_score REAL,
    ts         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
