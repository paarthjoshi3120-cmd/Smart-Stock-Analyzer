"""
Smart Stock Analyzer - Flask application
Team Code Geeks (Hariom Raturi, Paarth Joshi, Suryadev Singh) - OSDBMS-V-2026-T139

DBMS side : normalised SQLite schema, constraints, indexes, atomic ACID trades.
OS side   : one worker thread per request (Flask dev server), a background
            price-update thread, mutual exclusion via BEGIN IMMEDIATE write
            locks, fixed lock order (stocks -> users -> portfolio), and a
            bounded queue of work through SQLite's busy-timeout.

All prices are SYNTHETIC. This is an educational project, not financial advice.
"""
import math
import os
import random
import sqlite3
import statistics
import threading
from functools import wraps

from flask import (Flask, flash, g, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "stocks.db")
FEE_RATE = 0.001                      # 0.1 % brokerage per trade
PRICE_TICK_SECONDS = 5                # background price refresh interval
HISTORY_LIMIT = 400                   # price points kept per stock
START_CASH = 100_000.0

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-me-in-production")

# symbol, company, start price, shares available, annual volatility (synthetic)
SEED_STOCKS = [
    ("RELIANCE",  "Reliance Industries",     2850.0, 8000, 0.22),
    ("TCS",       "Tata Consultancy",        3900.0, 6000, 0.18),
    ("INFY",      "Infosys",                 1550.0, 7000, 0.21),
    ("HDFCBANK",  "HDFC Bank",               1650.0, 9000, 0.20),
    ("ITC",       "ITC Limited",              440.0, 12000, 0.16),
    ("WIPRO",     "Wipro",                    480.0, 9000, 0.26),
    ("SUNPHARMA", "Sun Pharma",              1500.0, 5000, 0.28),
    ("TATAMOTORS","Tata Motors",              960.0, 8000, 0.42),
    ("ADANIENT",  "Adani Enterprises",       2900.0, 4000, 0.52),
    ("ZOMATO",    "Zomato",                   230.0, 15000, 0.78),
]
VOL = {s[0]: s[4] for s in SEED_STOCKS}

# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def connect():
    c = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)  # manual transactions
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.execute("PRAGMA journal_mode = WAL")
    return c


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    if os.path.exists(DB_PATH):
        return
    rng = random.Random(42)
    c = connect()
    with open(os.path.join(BASE_DIR, "schema.sql")) as f:
        c.executescript(f.read())
    c.execute("BEGIN")
    for sym, comp, p0, qty, sigma in SEED_STOCKS:
        c.execute("INSERT INTO stocks(symbol,company,price,available_qty) VALUES (?,?,?,?)",
                  (sym, comp, p0, qty))
        sid = c.execute("SELECT stock_id FROM stocks WHERE symbol=?", (sym,)).fetchone()[0]
        price = p0
        rows = []
        for _ in range(250):   # one synthetic year of daily points (geometric Brownian motion)
            price *= math.exp(rng.gauss(0.0003, sigma / math.sqrt(252)))
            rows.append((sid, round(price, 2)))
        c.executemany("INSERT INTO price_history(stock_id,price) VALUES (?,?)", rows)
        c.execute("UPDATE stocks SET price=? WHERE stock_id=?", (rows[-1][1], sid))
    c.execute("COMMIT")
    c.close()


# --------------------------------------------------------------------------
# Analytics: risk score, decision engine, recommendation
# --------------------------------------------------------------------------
def risk_score(prices):
    """s = 0.5*min(vol/0.8,1) + 0.5*min(maxdrawdown/0.6,1)   (Eq. 4 of the paper)"""
    if len(prices) < 20:
        return 0.5
    rets = [math.log(b / a) for a, b in zip(prices, prices[1:])]
    vol = statistics.pstdev(rets) * math.sqrt(252)
    peak, mdd = prices[0], 0.0
    for p in prices:
        peak = max(peak, p)
        mdd = max(mdd, 1 - p / peak)
    return round(0.5 * min(vol / 0.8, 1) + 0.5 * min(mdd / 0.6, 1), 3)


def decision(score):
    """Threshold-based decision engine (Table 3 of the paper)."""
    if score < 0.40:
        return {"key": "allow", "label": "Allow access", "tone": "ok"}
    if score < 0.70:
        return {"key": "reminder", "label": "Risk reminder", "tone": "note"}
    if score <= 0.85:
        return {"key": "strong", "label": "Strong warning", "tone": "warn"}
    return {"key": "restrict", "label": "Trading restricted", "tone": "stop"}


def recommendation(prices, score):
    """Elementary rule: 20-point vs 50-point moving average, gated by risk."""
    if score > 0.85:
        return "Avoid"
    if len(prices) < 50:
        return "Neutral"
    sma20 = sum(prices[-20:]) / 20
    sma50 = sum(prices[-50:]) / 50
    if sma20 > sma50 and score < 0.70:
        return "Favourable"
    if sma20 < sma50:
        return "Weak trend"
    return "Neutral"


def recent_prices(db, stock_id, n=250):
    rows = db.execute("SELECT price FROM price_history WHERE stock_id=? ORDER BY id DESC LIMIT ?",
                      (stock_id, n)).fetchall()
    return [r["price"] for r in reversed(rows)]


def stock_view(db, row):
    prices = recent_prices(db, row["stock_id"])
    score = risk_score(prices)
    prev = prices[-2] if len(prices) > 1 else row["price"]
    return {**dict(row), "score": score, "decision": decision(score),
            "advice": recommendation(prices, score),
            "change": (row["price"] / prev - 1) * 100}


# --------------------------------------------------------------------------
# Background thread: simulated live prices
# --------------------------------------------------------------------------
_stop = threading.Event()


def price_updater():
    rng = random.Random()
    c = connect()
    while not _stop.wait(PRICE_TICK_SECONDS):      # sleeps between cycles (no busy waiting)
        try:
            c.execute("BEGIN IMMEDIATE")           # write lock -> never interleaves with a trade
            for s in c.execute("SELECT stock_id, symbol, price FROM stocks").fetchall():
                step = rng.gauss(0, VOL.get(s["symbol"], 0.3) / math.sqrt(252) * 2)
                new = max(round(s["price"] * math.exp(step), 2), 0.05)
                c.execute("UPDATE stocks SET price=? WHERE stock_id=?", (new, s["stock_id"]))
                c.execute("INSERT INTO price_history(stock_id,price) VALUES (?,?)", (s["stock_id"], new))
                c.execute("""DELETE FROM price_history WHERE stock_id=? AND id <= (
                               SELECT id FROM price_history WHERE stock_id=? ORDER BY id DESC LIMIT 1 OFFSET ?)""",
                          (s["stock_id"], s["stock_id"], HISTORY_LIMIT))
            c.execute("COMMIT")
        except sqlite3.Error:
            try:
                c.execute("ROLLBACK")
            except sqlite3.Error:
                pass


# --------------------------------------------------------------------------
# Auth
# --------------------------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if "uid" not in session:
            return redirect(url_for("login"))
        return view(*a, **kw)
    return wrapped


@app.context_processor
def inject_user():
    if "uid" in session:
        row = get_db().execute("SELECT name, cash FROM users WHERE user_id=?", (session["uid"],)).fetchone()
        if row:
            return {"me": row}
    return {"me": None}


@app.route("/")
def index():
    return redirect(url_for("stocks" if "uid" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        if not name or "@" not in email or len(pw) < 6:
            flash("Enter your name, a valid email and a password of at least 6 characters.", "error")
            return render_template("register.html")
        try:
            db = get_db()
            db.execute("INSERT INTO users(name,email,password_hash,cash) VALUES (?,?,?,?)",
                       (name, email, generate_password_hash(pw), START_CASH))
            flash("Account created. Sign in to start.", "ok")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        row = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if row and check_password_hash(row["password_hash"], request.form.get("password", "")):
            session.clear()
            session["uid"] = row["user_id"]
            get_db().execute("INSERT INTO logs(user_id,event) VALUES (?,?)", (row["user_id"], "login"))
            return redirect(url_for("stocks"))
        flash("Email or password is incorrect.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Stocks
# --------------------------------------------------------------------------
@app.route("/stocks")
@login_required
def stocks():
    db = get_db()
    rows = db.execute("SELECT * FROM stocks ORDER BY symbol").fetchall()
    return render_template("stocks.html", stocks=[stock_view(db, r) for r in rows])


@app.route("/api/prices")
@login_required
def api_prices():
    db = get_db()
    return jsonify([{"symbol": r["symbol"], "price": r["price"], "qty": r["available_qty"]}
                    for r in db.execute("SELECT symbol, price, available_qty FROM stocks")])


# --------------------------------------------------------------------------
# Trading: one atomic ACID transaction per order
# --------------------------------------------------------------------------
@app.route("/trade", methods=["POST"])
@login_required
def trade():
    uid = session["uid"]
    symbol = request.form.get("symbol", "")
    side = request.form.get("side", "")
    confirmed = request.form.get("confirm") == "on"
    try:
        qty = int(request.form.get("quantity", ""))
    except ValueError:
        qty = 0
    if side not in ("BUY", "SELL") or qty <= 0:
        flash("Enter a whole number of shares greater than zero.", "error")
        return redirect(url_for("stocks"))

    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")   # mutual exclusion: only one writer inside the critical section
        # lock order is always: stocks -> users -> portfolio (prevents circular wait)
        st = db.execute("SELECT * FROM stocks WHERE symbol=?", (symbol,)).fetchone()
        if not st:
            raise ValueError("Unknown stock symbol.")
        score = risk_score(recent_prices(db, st["stock_id"]))
        dec = decision(score)
        price = st["price"]
        fee = round(qty * price * FEE_RATE, 2)
        user = db.execute("SELECT cash FROM users WHERE user_id=?", (uid,)).fetchone()
        hold = db.execute("SELECT * FROM portfolio WHERE user_id=? AND stock_id=?",
                          (uid, st["stock_id"])).fetchone()

        if side == "BUY":
            if dec["key"] == "restrict":
                raise ValueError(f"{symbol} is in the restricted risk band (score {score:.2f}). Buying is disabled.")
            if dec["key"] == "strong" and not confirmed:
                raise ValueError(f"{symbol} has a high risk score ({score:.2f}). Tick the confirmation box to continue.")
            if qty > st["available_qty"]:
                raise ValueError(f"Only {st['available_qty']} shares of {symbol} are available.")
            cost = qty * price + fee
            if cost > user["cash"]:
                raise ValueError(f"Not enough cash. This order needs {cost:,.2f}.")
            db.execute("UPDATE stocks SET available_qty = available_qty - ? WHERE stock_id=?", (qty, st["stock_id"]))
            db.execute("UPDATE users SET cash = cash - ? WHERE user_id=?", (cost, uid))
            if hold:
                new_q = hold["quantity"] + qty
                new_avg = (hold["quantity"] * hold["avg_price"] + qty * price) / new_q   # Eq. (2)
                db.execute("""UPDATE portfolio SET quantity=?, avg_price=?, fees_paid=fees_paid+?
                              WHERE user_id=? AND stock_id=?""", (new_q, new_avg, fee, uid, st["stock_id"]))
            else:
                db.execute("INSERT INTO portfolio(user_id,stock_id,quantity,avg_price,fees_paid) VALUES (?,?,?,?,?)",
                           (uid, st["stock_id"], qty, price, fee))
            msg = f"Bought {qty} {symbol} at {price:,.2f} (fee {fee:,.2f})."
        else:
            if not hold or qty > hold["quantity"]:
                raise ValueError(f"You hold {hold['quantity'] if hold else 0} shares of {symbol}.")
            db.execute("UPDATE stocks SET available_qty = available_qty + ? WHERE stock_id=?", (qty, st["stock_id"]))
            db.execute("UPDATE users SET cash = cash + ? WHERE user_id=?", (qty * price - fee, uid))
            left = hold["quantity"] - qty
            if left == 0:
                db.execute("DELETE FROM portfolio WHERE user_id=? AND stock_id=?", (uid, st["stock_id"]))
            else:
                db.execute("""UPDATE portfolio SET quantity=?, fees_paid=fees_paid*?
                              WHERE user_id=? AND stock_id=?""",
                           (left, left / hold["quantity"], uid, st["stock_id"]))
            msg = f"Sold {qty} {symbol} at {price:,.2f} (fee {fee:,.2f})."

        db.execute("INSERT INTO transactions(user_id,stock_id,type,quantity,price,fee) VALUES (?,?,?,?,?,?)",
                   (uid, st["stock_id"], side, qty, price, fee))
        db.execute("INSERT INTO logs(user_id,event,risk_score) VALUES (?,?,?)",
                   (uid, f"{side} {qty} {symbol} [{dec['key']}]", score))
        db.execute("COMMIT")
        flash(msg + (f" Risk reminder: score {score:.2f}." if dec["key"] in ("reminder", "strong") else ""), "ok")
    except (ValueError, sqlite3.Error) as e:
        try:
            db.execute("ROLLBACK")           # all-or-nothing
        except sqlite3.Error:
            pass
        flash(str(e) if isinstance(e, ValueError) else "Trade could not be completed. Nothing was changed.", "error")
    return redirect(url_for("stocks"))


# --------------------------------------------------------------------------
# Portfolio and history
# --------------------------------------------------------------------------
@app.route("/portfolio")
@login_required
def portfolio():
    db = get_db()
    rows = db.execute("""SELECT p.*, s.symbol, s.company, s.price FROM portfolio p
                         JOIN stocks s ON s.stock_id = p.stock_id
                         WHERE p.user_id=? ORDER BY s.symbol""", (session["uid"],)).fetchall()
    items, total_value, total_cost = [], 0.0, 0.0
    for r in rows:
        q, avg, p = r["quantity"], r["avg_price"], r["price"]
        value, cost = q * p, q * avg
        items.append({**dict(r), "value": value, "pl": (p - avg) * q,
                      "ret": (p / avg - 1) * 100,
                      "breakeven": avg + r["fees_paid"] / q})     # Eq. (3)
        total_value += value
        total_cost += cost
    cash = db.execute("SELECT cash FROM users WHERE user_id=?", (session["uid"],)).fetchone()["cash"]
    return render_template("portfolio.html", items=items, total_value=total_value,
                           total_pl=total_value - total_cost, cash=cash,
                           net_worth=cash + total_value)


@app.route("/history")
@login_required
def history():
    rows = get_db().execute("""SELECT t.*, s.symbol FROM transactions t
                               JOIN stocks s ON s.stock_id = t.stock_id
                               WHERE t.user_id=? ORDER BY t.txn_id DESC LIMIT 200""",
                            (session["uid"],)).fetchall()
    return render_template("history.html", rows=rows)


if __name__ == "__main__":
    init_db()
    threading.Thread(target=price_updater, daemon=True).start()
    # threaded=True -> each request is served by its own worker thread
    app.run(debug=False, threaded=True, use_reloader=False)
